import { Specie } from "./specie.model";

export class SpecieFilm {
    id?: number;
    url: string;
    especie: Specie;
}