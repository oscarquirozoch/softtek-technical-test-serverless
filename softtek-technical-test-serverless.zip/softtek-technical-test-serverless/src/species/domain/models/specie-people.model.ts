import { Specie } from "./specie.model";

export class SpeciePeople {
    id?: number;
    url: string;
    especie: Specie;
}